# Personal Proxy + Chat Project

This starter project is a local chat application intended for a computer/server you own or administer. It does not implement school-filter or administrator bypassing.

## Run it

1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Create a virtual environment:

   `python -m venv .venv`

4. Activate it:

   Windows:
   `.venv\Scripts\activate`

   macOS/Linux:
   `source .venv/bin/activate`

5. Install dependencies:

   `pip install -r requirements.txt`

6. Start the server:

   `python app.py`

7. Open:

   `http://127.0.0.1:5000`

The chat currently broadcasts messages to everyone connected to this local server.

## Next safe additions

- Persistent message history with SQLite
- Login/authentication
- Private rooms
- User list
- Rate limiting
- Admin moderation controls
