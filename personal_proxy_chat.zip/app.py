from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit

app = Flask(__name__)
app.config["SECRET_KEY"] = "change-this-secret"
socketio = SocketIO(app, cors_allowed_origins="*")

@app.route("/")
def index():
    return render_template("index.html")

@socketio.on("join")
def handle_join(data):
    username = (data.get("username") or "Guest").strip()[:24]
    emit("system", {"text": f"{username} joined the chat."}, broadcast=True)

@socketio.on("message")
def handle_message(data):
    username = (data.get("username") or "Guest").strip()[:24]
    text = (data.get("text") or "").strip()[:500]
    if text:
        emit("message", {"username": username, "text": text}, broadcast=True)

if __name__ == "__main__":
    socketio.run(app, host="127.0.0.1", port=5000, debug=True)
